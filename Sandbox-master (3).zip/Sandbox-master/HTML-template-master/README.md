# HTML-template
This is the basic outline for all websites using html5.  Use the links below to loook up relevant information.

### HTML Tag Reference
  +  [MDN HTML](https://developer.mozilla.org/en-US/docs/Web/HTML/Element)

### CSS Property Reference
  +  [MDN CSS Syntax Writing](https://developer.mozilla.org/en-US/docs/Web/CSS/Syntax)
  +  [MDN CSS Property List](https://developer.mozilla.org/en-US/docs/Web/CSS/Reference#Concepts)
